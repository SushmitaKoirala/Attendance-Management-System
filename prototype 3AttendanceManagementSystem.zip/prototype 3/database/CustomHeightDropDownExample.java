
// import java.awt.*;
import javax.swing.*;

import java.awt.Color;
import java.awt.Font;
import java.sql.*;
import java.util.Vector;

public class CustomHeightDropDownExample {

    public static void main(String[] args) {
        JFrame frame = new JFrame("Custom Height Dropdown Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 600);
        frame.setResizable(false);
        frame.setLayout(null);
        frame.setVisible(true);
        frame.setFocusable(true);
        
        Font text = new Font("Times New Roman", Font.PLAIN, 18);
        // Font btn = new Font("Times New Roman", Font.BOLD, 20);
        
        JLabel classes = new JLabel("CLASS : ");
        classes.setFont(text);
        classes.setBounds(25, 150, 100, 20);
        classes.setForeground(Color.decode("#DEE4E7"));
        frame.add(classes);
        JComboBox<String> comboBox = new JComboBox<>();
        comboBox.setBounds(110, 150, 70, 25);
        frame.add(comboBox);

        populateComboBoxFromDatabase(comboBox);
    }

    private static void populateComboBoxFromDatabase(JComboBox<String> comboBox) {
        try {
            Connection con = DB.getConnection();

            Statement stm = con.createStatement();
            
            String query = "SELECT name FROM class";
            ResultSet resultSet = stm.executeQuery(query);

            // Create a vector to hold the options
            Vector<String> options = new Vector<>();

            // Add options from the result set to the vector
            while (resultSet.next()) {
                String option = resultSet.getString("name");
                options.add(option);
            }
            
            // // Populate the JComboBox with the options vector
            comboBox.setModel(new DefaultComboBoxModel<>(options));
            
            // // ... Close database resources ...
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }

}