#!/bin/bash

# List of SQL files to execute
sql_files=("AMSDatabase.sql")

# Database connection parameters
db_user="root"
db_name="AttendanceManagementSystem"
db_password=""

for file in "${sql_files[@]}"; do
  echo "Executing $file..."
  mysql -u "$db_user" -p"$db_password" "$db_name" < "$file"
done

echo "All SQL files executed."

